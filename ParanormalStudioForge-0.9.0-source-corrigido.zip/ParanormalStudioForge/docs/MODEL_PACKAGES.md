# Pacotes de modelo do Paranormal Studio (0.7.0)

O item **Biblioteca de Modelos Cinematográficos** abre o menu de pacotes e permite importar um ZIP. Os pacotes são extraídos para `config/paranormalstudio/models/`. O importador limita o ZIP a 512 entradas e 128 MB descompactados e rejeita caminhos que tentem sair da pasta de importação. Ainda assim, importe apenas arquivos de fontes confiáveis.

## Estrutura de pacote

Um ZIP deve conter `model.json` na raiz ou dentro de uma única pasta. Exemplo: 

```json
{
  "name": "Meu Monstro",
  "model": "monster.obj",
  "format": "obj",
  "animations": [
    { "name": "idle", "file": "animations/idle.json" },
    { "name": "walk", "file": "animations/walk.json" }
  ],
  "audio": [
    { "name": "tema", "file": "sounds/monster_theme.ogg" }
  ]
}
```

O menu verifica se o modelo e os caminhos de animação/áudio declarados existem e mostra contagens/avisos. Também aceita o formato antigo em que `animations` e `audio` são strings. Esta etapa **importa e valida os arquivos**, mas ainda não renderiza OBJ/GLB, não executa animações nem reproduz música.

## Sobre OBJ e animações

OBJ normalmente guarda geometria, não rigging, animações esqueléticas nem música. Para personagens animados, a futura integração deve usar um formato com rig/animações suportado pelo renderizador (por exemplo, Blockbench `.geo.json` com animações ou um carregador glTF/GLB dedicado). Música deve ficar em arquivos de áudio separados, como OGG.
