# BBS source notes

Input archive: `bbs-mod-master.zip`, archive root commit `3cbfc79b9168c1aa6f51e774820ff646140c0167`.

Verified from source files:
- `gradle.properties`: Minecraft 1.20.4, Yarn mappings, Fabric Loader 0.15.0, Fabric API 0.91.1+1.20.4, BBS version 1.7.7.
- `build.gradle`: Fabric Loom, split client/main source sets, Fabric API plus Sodium/Iris/Indium compile/runtime integration and shader libraries.
- `src/main/resources/fabric.mod.json`: Fabric entrypoints, mixins, access widener and Minecraft dependency `~1.20.4`.
- `README.md`: states 1.20.1 code is in a separate branch.

Porting approach: select one BBS feature at a time, trace all referenced Fabric APIs/mixins/access wideners/render hooks, port it behind a small adapter layer, then compile and test. Do not copy the entire Fabric source tree into a Forge project and claim compatibility.
