# Relatório de preparação — 0.9.0 (sem compilação)

## Correções aplicadas (por leitura do código)
1. `ModItems`: `ModBlocks.registerBlockItems(ITEMS)` estava duas vezes; o BlockItem `evidence_marker` seria registrado em duplicidade e o jogo falharia ao iniciar ("Duplicate registration"). Mantida uma chamada.
2. `InvestigationJournalItem`: faltava `import net.minecraft.world.InteractionResultHolder` (erro de compilação).
3. `mods.toml`: versão `0.1.0` -> `${mod_version}` (0.9.0), expandida por `processResources` em `build.gradle`.
4. Texturas de item inexistentes no vanilla trocadas (flashlight -> block/torch, emf_reader -> item/compass_00, evidence_case -> item/bundle). Não verificado no jogo.

## Não verificado
- Compilação: NÃO executada (ambiente sem javac, sem Java 17, sem DNS/rede).
- Nenhum teste automatizado existe no projeto; nenhum teste in-game foi feito.

## Lanterna / iluminação dinâmica
NÃO implementada. A lanterna só alterna a tag `LightOn` e toca som. Não foi adicionada luz dinâmica porque não é possível compilar nem testar aqui, e uma implementação não verificada (mixin de luz no cliente ou blocos de luz temporários) pode deixar luz presa no mundo ou quebrar o FPS.

## Riscos conhecidos (código original, preservado)
- `ModelLibraryScreen` usa `JFileChooser` (Swing/AWT), que pode travar ou falhar no macOS e em ambientes sem AWT.
- Bloco marcador sem loot table (não dropa item ao quebrar).
