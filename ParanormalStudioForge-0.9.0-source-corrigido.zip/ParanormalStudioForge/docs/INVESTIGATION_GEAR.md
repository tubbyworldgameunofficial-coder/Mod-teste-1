# Equipamento de investigação — 0.8.0

Esta etapa é aditiva: não remove nem renomeia os itens anteriores.

| Item | Comportamento atual | Próxima camada necessária |
|---|---|---|
| Lanterna | interação e som de ativação | luz dinâmica/iluminação persistente no cliente |
| Scanner UV existente | busca marcadores de evidência e emite partículas | decalques UV, pegadas e evidências tipadas |
| Leitor EMF | procura o marcador de evidência num raio de 10 blocos e sinaliza | níveis EMF, medidor animado e rede de evidências |
| Projetor DOTS | feixe demonstrativo de partículas | projeção persistente ajustável e renderização dedicada |
| Lupa | item registrado e interação informativa | inspeção de entidades/blocos e pistas |
| Microscópio | item registrado e interação informativa | sistema de amostras e interface de análise |
| Maleta | interação informativa | bloco/entidade com inventário e animação abrir/fechar |
| Fita de isolamento | registra a posição em mensagem | colocação de segmentos físicos e conexão entre postes |
| Câmera espectral | flash, busca evidência e indica coordenadas | fotografia real, filme/Polaroid e revelação de entidades invisíveis |
| Spray revelador | partículas de demonstração | marcação persistente de superfícies/evidências |

Os comportamentos ainda descritos como próximos passos não devem ser confundidos com recursos já concluídos. O modelo visual usa ícones vanilla provisórios; modelos/texturas próprios e animações serão uma etapa separada.
