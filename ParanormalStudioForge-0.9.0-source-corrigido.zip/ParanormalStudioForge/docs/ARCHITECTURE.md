# Architecture — 0.4.0

- `registry/ModBlocks`, `registry/ModItems`: Forge DeferredRegister declarations.
- `EvidenceMarkerBlock`: invisible persistent authoring marker; selected through normal block collision and revealed by scanner particles.
- `UVScannerItem`: server-authoritative nearest-marker search in an 17×17×17 cube (radius 8 on each axis); not a continuous held scanner yet.
- `InvestigationJournalItem`: item-stack NBT evidence ledger keyed by dimension and block coordinates.
- `RouteMarkerToolItem`: ordered position list in item-stack NBT; data is authoring metadata only, not an NPC controller.
- `ClapperboardItem`: take counter and location slate; no camera hooks.

## Next engineering gates

1. Compile with Gradle/ForgeGradle online; fix all compiler and resource errors.
2. Run a Forge 1.20.1 client and server smoke test.
3. Add dedicated unit tests for NBT de-duplication and route persistence.
4. Add a proper client renderer/event for continuous UV visibility, with bounded chunk iteration.
5. Add evidence types and a searchable journal screen.
6. Add NPC route execution and hunt AI only after entity registration, navigation, difficulty settings, and server-side safeguards are designed.
7. Implement cinematic camera/actor tooling as separate modules after choosing an explicit compatibility strategy for BBS.
