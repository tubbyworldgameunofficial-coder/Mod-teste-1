# Paranormal Studio Forge 0.9.0 — investigation gear interactions

This additive stage preserves all existing item IDs and systems. It adds server-side persistent state to the investigation gear:

- Investigation flashlight: toggles an on/off state on the item. Actual dynamic world lighting still requires a dedicated client rendering/light integration.
- EMF reader: scans for evidence markers and reports levels 1–5 based on distance.
- DOTS projector: toggles its demo particle beam; crouch-use cycles intensity 1–3.
- Magnifier: reports the block being looked at within five blocks.
- Evidence case: toggles open/closed state with a chest sound. A real container GUI/inventory is not implemented yet.
- Scene tape: records the last marked position and number of marks on the item. Physical tape geometry is not implemented yet.
- Spectral camera: counts photos on the item and runs the nearby evidence scan. It does not yet create an image file or Polaroid item.
- Evidence spray: searches for nearby evidence markers and reports the discovered coordinates.

## Validation status

The language JSON files are parsed as JSON and the ZIP is checked for integrity. A full Forge/Gradle compile must still be run in an environment with the Gradle distribution and Minecraft/Forge dependencies available. These interactions are not a claim of fully implemented lighting, animated 3D models, GUI inventories, or photographic rendering.
