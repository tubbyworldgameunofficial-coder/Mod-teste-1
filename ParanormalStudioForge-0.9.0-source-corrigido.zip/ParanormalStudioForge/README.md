# Paranormal Studio Forge — 0.4.0 (protótipo de desenvolvimento)

Mod para **Minecraft Java 1.20.1 + Forge 47.2.x + Java 17**. Este pacote é código-fonte, não um JAR instalável.

## Funcionalidades incluídas nesta etapa

- **Marcador de evidência oculto:** bloco persistente que não é renderizado normalmente. Continua com colisão/seleção de bloco; a varredura revela sua posição com partículas.
- **Scanner UV:** procura o marcador mais próximo num raio de 8 blocos, dá feedback visual/sonoro e consome durabilidade. A busca é executada no servidor.
- **Diário de investigação:** grava dimensão, coordenadas e tempo do mundo no NBT do item; evita duplicados; mostra total e até cinco registros recentes. Se estiver na mão secundária durante uma varredura bem-sucedida, registra a evidência encontrada.
- **Marcador de rota:** registra pontos ordenados em NBT para planejamento manual de rotas de NPC. Ainda não controla NPCs nem calcula pathfinding.
- **Claquete cinematográfica:** incrementa o número do take e mostra cena, dimensão e posição para organização de gravações. Ainda não controla câmera nem grava vídeo.

## Instalação de desenvolvimento

1. Instale Java 17 e Minecraft Forge MDK para 1.20.1.
2. Abra esta pasta no IntelliJ IDEA ou execute `./gradlew build` (Windows: `gradlew.bat build`).
3. O JAR, se o build terminar com sucesso, ficará em `build/libs/`.
4. Copie o JAR gerado para `.minecraft/mods` com Forge 1.20.1.

## Estado de validação

- Os JSONs de recursos e o ZIP-fonte foram verificados estruturalmente.
- **Compilação Java não confirmada:** o ambiente de criação não conseguiu baixar a distribuição Gradle por falha DNS/rede. Não distribua este código como JAR testado. Compile e teste em um ambiente com acesso aos repositórios Gradle/Minecraft.

## Ainda não implementado

IA de perseguição/entidade paranormal, fita policial funcional, GUI de evidências, renderização UV contínua, sistema real de câmera cinematográfica, gravação/reprodução de cenas, animação de atores, integração BBS e testes in-game. O código BBS fornecido anteriormente era de uma linha Fabric/1.20.4, não uma base Forge/1.20.1 pronta para integrar; esta versão não declara ser uma portagem completa do BBS.


## 0.7.0 — Biblioteca de modelos

Adicionado o item Biblioteca de Modelos Cinematográficos, com menu para abrir a pasta local e listar pacotes `model.json`. Consulte `docs/MODEL_PACKAGES.md`. A interface cataloga os metadados; não é ainda um importador/renderizador de OBJ/GLB nem um executor de animação/áudio.


## 0.7.0 — Importação de pacotes
- Biblioteca permite importar ZIP de pacote de modelo, com proteção contra caminhos ZIP maliciosos e limite de tamanho.
- Verifica a presença do modelo e dos caminhos declarados para animações e áudio.
- A reprodução real de modelos, animações e música ainda não está implementada.

## 0.8.0 — equipamentos de investigação (adição sem substituir itens existentes)

Foram adicionados nove itens ao registro criativo: lanterna, leitor EMF, projetor DOTS, lupa, microscópio, maleta de evidências, fita de isolamento, câmera espectral e spray revelador. O Scanner UV, diário, marcador de rota, claquete, biblioteca de modelos e marcador de evidência mantêm seus IDs e classes existentes.

**Limites honestos desta etapa:** EMF e câmera procuram o bloco marcador de evidência existente; DOTS emite um feixe demonstrativo de partículas. Algumas ferramentas ainda exibem uma mensagem de estado: iluminação real persistente, maleta com inventário, fita física colocável, amostras examináveis e fotografia com imagem/filme ainda precisam de implementação própria. Os ícones usam texturas vanilla provisórias. Ver `docs/INVESTIGATION_GEAR.md`.
