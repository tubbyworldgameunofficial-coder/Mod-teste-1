package com.paranormalstudio.item;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Lightweight on-set slate: maintains scene/take metadata on the item. */
public final class ClapperboardItem extends Item {
    public ClapperboardItem(Properties properties) { super(properties); }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            CompoundTag tag = stack.getOrCreateTag();
            int take = tag.getInt("TakeNumber") + 1;
            tag.putInt("TakeNumber", take);
            if (!tag.contains("SceneNumber")) tag.putInt("SceneNumber", 1);
            player.displayClientMessage(Component.translatable("message.paranormalstudio.slate", tag.getInt("SceneNumber"), take, level.dimension().location().toString(), player.blockPosition().getX(), player.blockPosition().getY(), player.blockPosition().getZ()), false);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
