package com.paranormalstudio.item;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Records ordered NPC/blocking marks on the tool; this is an authoring aid, not autonomous NPC pathfinding. */
public final class RouteMarkerToolItem extends Item {
    private static final String KEY = "ParanormalRouteNodes";
    public RouteMarkerToolItem(Properties properties) { super(properties); }

    @Override public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        Player player = context.getPlayer();
        if (player == null) return InteractionResult.PASS;
        if (level.isClientSide) return InteractionResult.SUCCESS;
        ItemStack stack = context.getItemInHand();
        CompoundTag root = stack.getOrCreateTag();
        ListTag nodes = root.getList(KEY, Tag.TAG_COMPOUND);
        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
        CompoundTag node = new CompoundTag();
        node.putInt("X", pos.getX()); node.putInt("Y", pos.getY()); node.putInt("Z", pos.getZ());
        node.putString("Dimension", level.dimension().location().toString());
        nodes.add(node); root.put(KEY, nodes);
        if (level instanceof ServerLevel server) server.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX()+0.5, pos.getY()+0.5, pos.getZ()+0.5, 6, .15, .2, .15, 0.01);
        player.displayClientMessage(Component.translatable("message.paranormalstudio.route_added", nodes.size(), pos.getX(), pos.getY(), pos.getZ()), true);
        return InteractionResult.CONSUME;
    }

    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            int count = stack.getOrCreateTag().getList(KEY, Tag.TAG_COMPOUND).size();
            player.displayClientMessage(Component.translatable("message.paranormalstudio.route_summary", count), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
