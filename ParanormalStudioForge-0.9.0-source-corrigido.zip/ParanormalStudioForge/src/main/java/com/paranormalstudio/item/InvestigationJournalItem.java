package com.paranormalstudio.item;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Block;

/** A portable case notebook. Entries are stored on the ItemStack and survive saves/restarts. */
public final class InvestigationJournalItem extends Item {
    private static final String ENTRIES_KEY = "ParanormalEvidenceEntries";

    public InvestigationJournalItem(Properties properties) { super(properties); }

    public static boolean recordEvidence(Level level, BlockPos pos, Player player, ItemStack journal) {
        if (level.isClientSide) return false;
        CompoundTag root = journal.getOrCreateTag();
        ListTag entries = root.getList(ENTRIES_KEY, Tag.TAG_COMPOUND);
        String dimension = level.dimension().location().toString();
        for (int i = 0; i < entries.size(); i++) {
            CompoundTag entry = entries.getCompound(i);
            if (entry.getString("Dimension").equals(dimension)
                    && entry.getInt("X") == pos.getX()
                    && entry.getInt("Y") == pos.getY()
                    && entry.getInt("Z") == pos.getZ()) {
                player.displayClientMessage(Component.translatable("message.paranormalstudio.journal_duplicate"), true);
                return false;
            }
        }
        CompoundTag entry = new CompoundTag();
        entry.putString("Dimension", dimension);
        entry.putInt("X", pos.getX());
        entry.putInt("Y", pos.getY());
        entry.putInt("Z", pos.getZ());
        entry.putLong("RecordedAt", level.getGameTime());
        entries.add(entry);
        root.put(ENTRIES_KEY, entries);
        player.displayClientMessage(Component.translatable("message.paranormalstudio.journal_recorded", entries.size(), pos.getX(), pos.getY(), pos.getZ()), true);
        return true;
    }

    @Override
    public InteractionResult useOn( net.minecraft.world.item.context.UseOnContext context) {
        Level level = context.getLevel();
        Player player = context.getPlayer();
        if (player == null) return InteractionResult.PASS;
        if (level.isClientSide) return InteractionResult.SUCCESS;
        ItemStack stack = context.getItemInHand();
        int count = stack.getOrCreateTag().getList(ENTRIES_KEY, Tag.TAG_COMPOUND).size();
        player.displayClientMessage(Component.translatable("message.paranormalstudio.journal_summary", count), true);
        return InteractionResult.CONSUME;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            ListTag entries = stack.getOrCreateTag().getList(ENTRIES_KEY, Tag.TAG_COMPOUND);
            int count = entries.size();
            player.displayClientMessage(Component.translatable("message.paranormalstudio.journal_summary", count), false);
            int start = Math.max(0, count - 5);
            for (int i = start; i < count; i++) {
                CompoundTag entry = entries.getCompound(i);
                player.displayClientMessage(Component.literal("#" + (i + 1) + " " + entry.getString("Dimension")
                        + " — X=" + entry.getInt("X") + " Y=" + entry.getInt("Y") + " Z=" + entry.getInt("Z")), false);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
