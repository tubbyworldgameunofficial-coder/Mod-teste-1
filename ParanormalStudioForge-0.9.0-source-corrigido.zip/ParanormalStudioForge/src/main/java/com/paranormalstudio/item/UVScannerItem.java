package com.paranormalstudio.item;

import com.paranormalstudio.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Scans for persistent evidence markers near the player; all detection is server-authoritative. */
public final class UVScannerItem extends Item {
    private static final int RADIUS = 8;
    public UVScannerItem(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);

        BlockPos origin = player.blockPosition();
        BlockPos found = null;
        double nearestDistance = Double.MAX_VALUE;
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        for (int x = -RADIUS; x <= RADIUS; x++) {
            for (int y = -RADIUS; y <= RADIUS; y++) {
                for (int z = -RADIUS; z <= RADIUS; z++) {
                    cursor.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z);
                    if (!level.getBlockState(cursor).is(ModBlocks.EVIDENCE_MARKER.get())) continue;
                    double distance = player.distanceToSqr(Vec3.atCenterOf(cursor));
                    if (distance < nearestDistance) {
                        nearestDistance = distance;
                        found = cursor.immutable();
                    }
                }
            }
        }

        if (found != null && level instanceof ServerLevel serverLevel) {
            Vec3 center = Vec3.atCenterOf(found).add(0, 0.25, 0);
            serverLevel.sendParticles(ParticleTypes.END_ROD, center.x, center.y, center.z, 22,
                    0.28, 0.35, 0.28, 0.015);
            serverLevel.sendParticles(ParticleTypes.WITCH, center.x, center.y, center.z, 10,
                    0.2, 0.25, 0.2, 0.01);
            serverLevel.playSound(null, found, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.55F, 1.55F);
            player.displayClientMessage(Component.translatable("message.paranormalstudio.evidence_found",
                    found.getX(), found.getY(), found.getZ()), true);
            ItemStack offhand = player.getOffhandItem();
            if (offhand.getItem() instanceof InvestigationJournalItem) {
                InvestigationJournalItem.recordEvidence(level, found, player, offhand);
            }
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
        } else {
            player.displayClientMessage(Component.translatable("message.paranormalstudio.evidence_none"), true);
        }
        return InteractionResultHolder.success(stack);
    }
}
