package com.paranormalstudio.item;

import com.paranormalstudio.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Stateful investigation tools. All evidence detection and state changes are server-authoritative. */
public final class InvestigationGearItem extends Item {
    public enum Gear { FLASHLIGHT, EMF_READER, DOTS_PROJECTOR, MAGNIFIER, MICROSCOPE, EVIDENCE_CASE, SCENE_TAPE, SPECTRAL_CAMERA, EVIDENCE_SPRAY }
    private final Gear gear;
    public InvestigationGearItem(Properties properties, Gear gear) { super(properties); this.gear = gear; }

    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) return InteractionResultHolder.success(stack);
        BlockPos pos = player.blockPosition();
        switch (gear) {
            case FLASHLIGHT -> {
                boolean on = !stack.getOrCreateTag().getBoolean("LightOn");
                stack.getOrCreateTag().putBoolean("LightOn", on);
                level.playSound(null, pos, SoundEvents.LEVER_CLICK, SoundSource.PLAYERS, .45F, on ? 1.7F : .8F);
                player.displayClientMessage(Component.translatable(on ? "message.paranormalstudio.flashlight_on" : "message.paranormalstudio.flashlight_off"), true);
            }
            case EMF_READER -> scan(level, player, 10, "emf");
            case DOTS_PROJECTOR -> {
                var tag = stack.getOrCreateTag();
                int intensity = Math.max(1, Math.min(3, tag.getInt("DotsIntensity")));
                if (player.isCrouching()) {
                    intensity = intensity % 3 + 1;
                    tag.putInt("DotsIntensity", intensity);
                    player.displayClientMessage(Component.translatable("message.paranormalstudio.dots_intensity", intensity), true);
                } else {
                    boolean on = !tag.getBoolean("DotsOn");
                    tag.putBoolean("DotsOn", on);
                    if (on && level instanceof ServerLevel server) {
                        Vec3 eye = player.getEyePosition(); Vec3 look = player.getLookAngle();
                        for (int i = 1; i <= 12; i++) {
                            Vec3 p = eye.add(look.scale(i));
                            server.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, intensity * 2, .12, .12, .12, .002);
                        }
                    }
                    player.displayClientMessage(Component.translatable(on ? "message.paranormalstudio.dots_active" : "message.paranormalstudio.dots_off"), true);
                    level.playSound(null, pos, SoundEvents.BEACON_AMBIENT, SoundSource.PLAYERS, .25F, on ? 1.8F : .8F);
                }
            }
            case MAGNIFIER -> {
                BlockPos target = playerPickBlock(player, 5);
                if (target != null) player.displayClientMessage(Component.translatable("message.paranormalstudio.inspect_block", level.getBlockState(target).getBlock().getName()), true);
                else player.displayClientMessage(Component.translatable("message.paranormalstudio.magnifier_hint"), true);
            }
            case MICROSCOPE -> player.displayClientMessage(Component.translatable("message.paranormalstudio.microscope_hint"), true);
            case EVIDENCE_CASE -> {
                boolean open = !stack.getOrCreateTag().getBoolean("CaseOpen");
                stack.getOrCreateTag().putBoolean("CaseOpen", open);
                player.displayClientMessage(Component.translatable(open ? "message.paranormalstudio.case_open" : "message.paranormalstudio.case_closed"), true);
                level.playSound(null, pos, SoundEvents.CHEST_OPEN, SoundSource.PLAYERS, .6F, open ? 1F : .8F);
            }
            case SCENE_TAPE -> {
                stack.getOrCreateTag().putLong("LastMarkedPos", pos.asLong());
                stack.getOrCreateTag().putInt("MarksMade", stack.getOrCreateTag().getInt("MarksMade") + 1);
                player.displayClientMessage(Component.translatable("message.paranormalstudio.tape_mark", pos.getX(), pos.getY(), pos.getZ()), true);
            }
            case SPECTRAL_CAMERA -> {
                int photos = stack.getOrCreateTag().getInt("PhotosTaken") + 1;
                stack.getOrCreateTag().putInt("PhotosTaken", photos);
                level.playSound(null, pos, SoundEvents.FIREWORK_ROCKET_BLAST, SoundSource.PLAYERS, .5F, 1.35F);
                if (level instanceof ServerLevel server) server.sendParticles(ParticleTypes.FLASH, pos.getX()+.5, pos.getY()+1.4, pos.getZ()+.5, 1, 0, 0, 0, 0);
                player.displayClientMessage(Component.translatable("message.paranormalstudio.photo_count", photos), true);
                scan(level, player, 12, "photo");
            }
            case EVIDENCE_SPRAY -> {
                if (level instanceof ServerLevel server) {
                    Vec3 eye = player.getEyePosition(); Vec3 look = player.getLookAngle();
                    for (int i=1;i<=5;i++) { Vec3 p=eye.add(look.scale(i)); server.sendParticles(ParticleTypes.SPLASH, p.x,p.y,p.z, 5,.12,.12,.12,.01); }
                }
                BlockPos found = findEvidence(level, player, 5);
                if (found != null) player.displayClientMessage(Component.translatable("message.paranormalstudio.spray_revealed", found.getX(), found.getY(), found.getZ()), true);
                else player.displayClientMessage(Component.translatable("message.paranormalstudio.spray_used"), true);
            }
        }
        return InteractionResultHolder.success(stack);
    }

    private static BlockPos playerPickBlock(Player player, double range) {
        var hit = player.pick(range, 0, false);
        return hit instanceof net.minecraft.world.phys.BlockHitResult blockHit && hit.getType() == net.minecraft.world.phys.HitResult.Type.BLOCK ? blockHit.getBlockPos() : null;
    }

    private static BlockPos findEvidence(Level level, Player player, int radius) {
        BlockPos origin = player.blockPosition(), found = null;
        double best = Double.MAX_VALUE;
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        for (int x=-radius;x<=radius;x++) for (int y=-radius;y<=radius;y++) for (int z=-radius;z<=radius;z++) {
            cursor.set(origin.getX()+x, origin.getY()+y, origin.getZ()+z);
            if (!level.getBlockState(cursor).is(ModBlocks.EVIDENCE_MARKER.get())) continue;
            double d=player.distanceToSqr(Vec3.atCenterOf(cursor));
            if(d<best){best=d;found=cursor.immutable();}
        }
        return found;
    }

    private static void scan(Level level, Player player, int radius, String mode) {
        BlockPos found = findEvidence(level, player, radius);
        if (found != null) {
            double distance = Math.sqrt(player.distanceToSqr(Vec3.atCenterOf(found)));
            if (level instanceof ServerLevel server) {
                Vec3 p=Vec3.atCenterOf(found);
                server.sendParticles(mode.equals("photo") ? ParticleTypes.FLASH : ParticleTypes.ELECTRIC_SPARK, p.x,p.y+.3,p.z, 18,.25,.3,.25,.015);
                server.playSound(null, found, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, .6F, 1.2F);
            }
            if (mode.equals("emf")) {
                int strength = distance <= 2 ? 5 : distance <= 4 ? 4 : distance <= 6 ? 3 : distance <= 8 ? 2 : 1;
                player.displayClientMessage(Component.translatable("message.paranormalstudio.emf_level", strength, found.getX(), found.getY(), found.getZ()), true);
            } else player.displayClientMessage(Component.translatable("message.paranormalstudio.gear_found", found.getX(),found.getY(),found.getZ()), true);
        } else player.displayClientMessage(Component.translatable(mode.equals("photo") ? "message.paranormalstudio.photo_none" : "message.paranormalstudio.emf_none"), true);
    }
}
