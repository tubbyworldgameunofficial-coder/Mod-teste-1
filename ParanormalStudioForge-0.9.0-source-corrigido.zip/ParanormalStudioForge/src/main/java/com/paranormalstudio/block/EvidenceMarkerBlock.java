package com.paranormalstudio.block;

import com.paranormalstudio.item.InvestigationJournalItem;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.phys.BlockHitResult;

/** Persistent placeable marker used to author evidence locations in a scene. */
public final class EvidenceMarkerBlock extends Block {
    public EvidenceMarkerBlock() {
        super(Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(0.5F)
                .sound(SoundType.AMETHYST).noOcclusion());
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        if (held.getItem() instanceof InvestigationJournalItem) {
            if (level.isClientSide) return InteractionResult.SUCCESS;
            InvestigationJournalItem.recordEvidence(level, pos, player, held);
            return InteractionResult.CONSUME;
        }
        return InteractionResult.PASS;
    }
}
