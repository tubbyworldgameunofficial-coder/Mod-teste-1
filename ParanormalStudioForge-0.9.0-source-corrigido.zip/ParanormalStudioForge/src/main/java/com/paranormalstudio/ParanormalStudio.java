package com.paranormalstudio;

import com.mojang.logging.LogUtils;
import com.paranormalstudio.registry.ModBlocks;
import com.paranormalstudio.registry.ModItems;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(ParanormalStudio.MOD_ID)
public final class ParanormalStudio {
    public static final String MOD_ID = "paranormalstudio";
    public static final Logger LOGGER = LogUtils.getLogger();

    public ParanormalStudio() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        modBus.addListener(this::addCreativeTabItems);
        LOGGER.info("Paranormal Studio {} starting", "0.9.0");
    }

    private void addCreativeTabItems(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(ModItems.UV_SCANNER);
            event.accept(ModItems.INVESTIGATION_JOURNAL);
            event.accept(ModItems.ROUTE_MARKER);
            event.accept(ModItems.CLAPPERBOARD);
            event.accept(ModItems.MODEL_LIBRARY);
            event.accept(ModItems.FLASHLIGHT);
            event.accept(ModItems.EMF_READER);
            event.accept(ModItems.DOTS_PROJECTOR);
            event.accept(ModItems.MAGNIFIER);
            event.accept(ModItems.MICROSCOPE);
            event.accept(ModItems.EVIDENCE_CASE);
            event.accept(ModItems.SCENE_TAPE);
            event.accept(ModItems.SPECTRAL_CAMERA);
            event.accept(ModItems.EVIDENCE_SPRAY);
        }
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(ModBlocks.EVIDENCE_MARKER);
        }
    }
}
