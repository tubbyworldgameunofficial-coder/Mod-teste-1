package com.paranormalstudio.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.Util;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

/** Client-side model package browser. It catalogs bundles; it does not claim to render OBJ/GLB yet. */
public final class ModelLibraryScreen extends Screen {
    private static final Logger LOGGER = LogUtils.getLogger();
    private final Path library = FMLPaths.CONFIGDIR.get().resolve("paranormalstudio").resolve("models");
    private final List<String> rows = new ArrayList<>();
    private String status = "";
    private int scroll;

    public ModelLibraryScreen() { super(Component.translatable("screen.paranormalstudio.model_library")); }

    @Override
    protected void init() {
        int center = this.width / 2;
        this.addRenderableWidget(Button.builder(Component.translatable("screen.paranormalstudio.import_zip"), b -> importZip())
                .bounds(center - 75, this.height - 72, 150, 20).build());
        this.addRenderableWidget(Button.builder(Component.translatable("screen.paranormalstudio.open_folder"), b -> openFolder())
                .bounds(center - 154, this.height - 48, 148, 20).build());
        this.addRenderableWidget(Button.builder(Component.translatable("screen.paranormalstudio.refresh"), b -> refresh())
                .bounds(center + 6, this.height - 48, 148, 20).build());
        this.addRenderableWidget(Button.builder(Component.translatable("gui.done"), b -> this.onClose())
                .bounds(center - 50, this.height - 24, 100, 20).build());
        refresh();
    }

    private void openFolder() {
        try {
            Files.createDirectories(library);
            Util.getPlatform().openFile(library.toFile());
            status = Component.translatable("screen.paranormalstudio.folder_opened").getString();
        } catch (IOException e) {
            LOGGER.error("Could not open model library folder", e);
            status = Component.translatable("screen.paranormalstudio.folder_error").getString();
        }
    }

    private void refresh() {
        rows.clear();
        try {
            Files.createDirectories(library);
            try (Stream<Path> paths = Files.list(library)) {
                paths.filter(Files::isDirectory).sorted(Comparator.comparing(p -> p.getFileName().toString()))
                    .forEach(dir -> rows.add(readPackage(dir)));
            }
            status = rows.isEmpty() ? Component.translatable("screen.paranormalstudio.empty").getString()
                    : Component.translatable("screen.paranormalstudio.found", rows.size()).getString();
        } catch (IOException e) {
            LOGGER.error("Could not scan model library", e);
            status = Component.translatable("screen.paranormalstudio.scan_error").getString();
        }
    }

    private void importZip() {
        try {
            Files.createDirectories(library);
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle(Component.translatable("screen.paranormalstudio.choose_zip").getString());
            chooser.setFileFilter(new FileNameExtensionFilter("Model package (*.zip)", "zip"));
            if (chooser.showOpenDialog(null) != JFileChooser.APPROVE_OPTION) return;
            Path archive = chooser.getSelectedFile().toPath();
            Path staging = Files.createTempDirectory(library, ".import-");
            boolean imported = false;
            try {
                int entries = 0;
                long totalBytes = 0;
                try (InputStream fileIn = Files.newInputStream(archive); ZipInputStream zip = new ZipInputStream(fileIn)) {
                    ZipEntry entry;
                    while ((entry = zip.getNextEntry()) != null) {
                        if (++entries > 512) throw new IOException("ZIP excede 512 arquivos");
                        Path target = staging.resolve(entry.getName()).normalize();
                        if (!target.startsWith(staging) || entry.getName().startsWith("/") || entry.getName().contains("\\"))
                            throw new IOException("Caminho inseguro no ZIP");
                        if (entry.isDirectory()) {
                            Files.createDirectories(target);
                        } else {
                            Files.createDirectories(target.getParent());
                            try (OutputStream out = Files.newOutputStream(target)) {
                                byte[] buffer = new byte[8192];
                                int read;
                                while ((read = zip.read(buffer)) != -1) {
                                    totalBytes += read;
                                    if (totalBytes > 128L * 1024L * 1024L) throw new IOException("ZIP excede 128 MB descompactados");
                                    out.write(buffer, 0, read);
                                }
                            }
                        }
                        zip.closeEntry();
                    }
                }
                Path packageRoot = staging;
                if (!Files.isRegularFile(packageRoot.resolve("model.json"))) {
                    try (Stream<Path> children = Files.list(staging)) {
                        List<Path> dirs = children.filter(Files::isDirectory).toList();
                        if (dirs.size() == 1 && Files.isRegularFile(dirs.get(0).resolve("model.json"))) packageRoot = dirs.get(0);
                    }
                }
                if (!Files.isRegularFile(packageRoot.resolve("model.json")))
                    throw new IOException("O ZIP precisa conter model.json na raiz ou em uma única pasta");
                String folderName = safeFolderName(packageRoot.getFileName().toString());
                if (packageRoot.equals(staging)) folderName = safeFolderName(archive.getFileName().toString().replaceFirst("(?i)\\.zip$", ""));
                Path destination = uniqueDestination(folderName);
                if (packageRoot.equals(staging)) Files.move(staging, destination, StandardCopyOption.REPLACE_EXISTING);
                else Files.move(packageRoot, destination, StandardCopyOption.REPLACE_EXISTING);
                imported = true;
                status = Component.translatable("screen.paranormalstudio.import_success", destination.getFileName().toString()).getString();
            } finally {
                if (Files.exists(staging)) deleteTree(staging);
            }
            refreshRowsPreservingStatus();
        } catch (Exception e) {
            LOGGER.error("Failed to import model package ZIP", e);
            status = Component.translatable("screen.paranormalstudio.import_error", e.getMessage() == null ? "erro desconhecido" : e.getMessage()).getString();
        }
    }

    private Path uniqueDestination(String base) {
        Path result = library.resolve(base);
        int suffix = 2;
        while (Files.exists(result)) result = library.resolve(base + "-" + suffix++);
        return result;
    }

    private static String safeFolderName(String raw) {
        String safe = raw.replaceAll("[^a-zA-Z0-9._-]", "_");
        if (safe.isBlank() || safe.equals(".") || safe.equals("..")) return "model_package";
        return safe.length() > 64 ? safe.substring(0, 64) : safe;
    }

    private static void deleteTree(Path root) throws IOException {
        if (!Files.exists(root)) return;
        try (Stream<Path> walk = Files.walk(root)) {
            for (Path path : walk.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);
        }
    }

    private void refreshRowsPreservingStatus() {
        String previousStatus = status;
        refresh();
        status = previousStatus;
    }

    private String readPackage(Path dir) {
        Path manifest = dir.resolve("model.json");
        if (!Files.isRegularFile(manifest)) return dir.getFileName() + " — model.json ausente";
        try {
            JsonObject json = JsonParser.parseString(Files.readString(manifest, StandardCharsets.UTF_8)).getAsJsonObject();
            String name = json.has("name") ? json.get("name").getAsString() : dir.getFileName().toString();
            String model = json.has("model") ? json.get("model").getAsString() : "";
            List<String> issues = new ArrayList<>();
            if (model.isBlank()) issues.add("modelo ausente");
            else if (!safeReferencedFile(dir, model)) issues.add("modelo não encontrado/caminho inválido");
            int animationCount = 0;
            JsonElement animations = json.get("animations");
            if (animations != null && animations.isJsonArray()) {
                for (JsonElement element : animations.getAsJsonArray()) {
                    if (element.isJsonObject()) {
                        String file = stringField(element.getAsJsonObject(), "file");
                        if (!file.isBlank() && safeReferencedFile(dir, file)) animationCount++;
                        else issues.add("arquivo de animação ausente");
                    } else if (element.isJsonPrimitive()) animationCount++;
                }
            } else if (animations != null && animations.isJsonPrimitive()) {
                String file = animations.getAsString();
                if (!file.isBlank() && safeReferencedFile(dir, file)) animationCount++;
                else if (!file.isBlank()) issues.add("arquivo de animação não encontrado");
            }
            int audioCount = 0;
            JsonElement audio = json.get("audio");
            if (audio != null && audio.isJsonArray()) {
                for (JsonElement element : audio.getAsJsonArray()) {
                    String file = element.isJsonObject() ? stringField(element.getAsJsonObject(), "file") : (element.isJsonPrimitive() ? element.getAsString() : "");
                    if (!file.isBlank() && safeReferencedFile(dir, file)) audioCount++;
                    else issues.add("arquivo de áudio ausente");
                }
            } else if (audio != null && audio.isJsonPrimitive()) {
                String file = audio.getAsString();
                if (!file.isBlank() && safeReferencedFile(dir, file)) audioCount++;
                else if (!file.isBlank()) issues.add("arquivo de áudio não encontrado");
            }
            String statusText = issues.isEmpty() ? "pacote verificado" : String.join(", ", issues);
            return name + " | modelo: " + (model.isBlank() ? "não definido" : model) + " | animações: " + animationCount + " | áudios: " + audioCount + " | " + statusText;
        } catch (Exception e) {
            return dir.getFileName() + " — model.json inválido";
        }
    }

    private static String stringField(JsonObject object, String field) {
        return object.has(field) && object.get(field).isJsonPrimitive() ? object.get(field).getAsString() : "";
    }

    private static boolean safeReferencedFile(Path root, String relative) {
        try {
            Path target = root.resolve(relative).normalize();
            return target.startsWith(root.normalize()) && Files.isRegularFile(target);
        } catch (Exception ignored) { return false; }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 16, 0xFFFFFF);
        graphics.drawCenteredString(this.font, Component.translatable("screen.paranormalstudio.model_path", library.toString()), this.width / 2, 32, 0xAAAAAA);
        int y = 54;
        int max = Math.max(0, rows.size() - 1);
        scroll = Math.min(scroll, max);
        for (int i = scroll; i < rows.size() && y < this.height - 78; i++) {
            graphics.drawString(this.font, rows.get(i), 12, y, 0xE0E0E0, false);
            y += 14;
        }
        graphics.drawCenteredString(this.font, status, this.width / 2, this.height - 62, 0x80FF80);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        scroll = Math.max(0, Math.min(Math.max(0, rows.size() - 1), scroll - (int)Math.signum(delta) * 3));
        return true;
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
