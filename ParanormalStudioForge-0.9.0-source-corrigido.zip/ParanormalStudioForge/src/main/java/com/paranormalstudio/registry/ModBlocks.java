package com.paranormalstudio.registry;

import com.paranormalstudio.ParanormalStudio;
import com.paranormalstudio.block.EvidenceMarkerBlock;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ParanormalStudio.MOD_ID);
    public static final RegistryObject<Block> EVIDENCE_MARKER = BLOCKS.register("evidence_marker", EvidenceMarkerBlock::new);

    public static void registerBlockItems(DeferredRegister<Item> items) {
        items.register("evidence_marker", () -> new BlockItem(EVIDENCE_MARKER.get(), new Item.Properties()));
    }

    private ModBlocks() { }
}
