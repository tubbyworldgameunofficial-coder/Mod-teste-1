package com.paranormalstudio.registry;

import com.paranormalstudio.ParanormalStudio;
import com.paranormalstudio.item.UVScannerItem;
import com.paranormalstudio.item.InvestigationJournalItem;
import com.paranormalstudio.item.RouteMarkerToolItem;
import com.paranormalstudio.item.ClapperboardItem;
import com.paranormalstudio.item.ModelLibraryItem;
import com.paranormalstudio.item.InvestigationGearItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ParanormalStudio.MOD_ID);
    static { ModBlocks.registerBlockItems(ITEMS); }
    public static final RegistryObject<Item> UV_SCANNER = ITEMS.register("uv_scanner",
            () -> new UVScannerItem(new Item.Properties().stacksTo(1).durability(256)));
    public static final RegistryObject<Item> INVESTIGATION_JOURNAL = ITEMS.register("investigation_journal",
            () -> new InvestigationJournalItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ROUTE_MARKER = ITEMS.register("route_marker",
            () -> new RouteMarkerToolItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> CLAPPERBOARD = ITEMS.register("clapperboard",
            () -> new ClapperboardItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> MODEL_LIBRARY = ITEMS.register("model_library",
            () -> new ModelLibraryItem(new Item.Properties().stacksTo(1)));
    // Additive investigation equipment; existing item IDs and behavior remain unchanged.
    public static final RegistryObject<Item> FLASHLIGHT = gear("flashlight", InvestigationGearItem.Gear.FLASHLIGHT);
    public static final RegistryObject<Item> EMF_READER = gear("emf_reader", InvestigationGearItem.Gear.EMF_READER);
    public static final RegistryObject<Item> DOTS_PROJECTOR = gear("dots_projector", InvestigationGearItem.Gear.DOTS_PROJECTOR);
    public static final RegistryObject<Item> MAGNIFIER = gear("magnifier", InvestigationGearItem.Gear.MAGNIFIER);
    public static final RegistryObject<Item> MICROSCOPE = gear("microscope", InvestigationGearItem.Gear.MICROSCOPE);
    public static final RegistryObject<Item> EVIDENCE_CASE = gear("evidence_case", InvestigationGearItem.Gear.EVIDENCE_CASE);
    public static final RegistryObject<Item> SCENE_TAPE = gear("scene_tape", InvestigationGearItem.Gear.SCENE_TAPE);
    public static final RegistryObject<Item> SPECTRAL_CAMERA = gear("spectral_camera", InvestigationGearItem.Gear.SPECTRAL_CAMERA);
    public static final RegistryObject<Item> EVIDENCE_SPRAY = gear("evidence_spray", InvestigationGearItem.Gear.EVIDENCE_SPRAY);
    private static RegistryObject<Item> gear(String id, InvestigationGearItem.Gear type) {
        return ITEMS.register(id, () -> new InvestigationGearItem(new Item.Properties().stacksTo(1), type));
    }
    private ModItems() { }
}
